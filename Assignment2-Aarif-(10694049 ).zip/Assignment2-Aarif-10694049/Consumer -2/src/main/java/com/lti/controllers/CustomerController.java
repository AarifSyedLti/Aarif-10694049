package com.lti.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CustomerController {
	
	/*
	 * @Autowired private DiscoveryClient discoveryClient;
	 */ //
	
	@Autowired
	private LoadBalancerClient loadBalancer;
	
	@RequestMapping(value = "/findemployee", method = RequestMethod.GET)
	public String getCustomerfromStaffService() {
		
		
		//List<ServiceInstance> instances=discoveryClient.getInstances("EMPLOYEE-PRODUCER");  // this is for discovery client
		ServiceInstance serviceInstance=loadBalancer.choose("employee-producer");   // this is for loadbalancer client
		String baseUrl=serviceInstance.getUri().toString();
				baseUrl=baseUrl+"/employee";
		System.out.println(baseUrl);
		RestTemplate restTemplate = new RestTemplate();
		String response=null;
		
		
		response=restTemplate.getForObject(baseUrl,String.class);
		
		
		System.out.println("============"+response);
	
		
		return response;
		
	}
	
	/*
	 * if(emp.getName().equalsIgnoreCase("emp1")) throw new RuntimeException();
	 * 
	 * return emp;
	 */
	
	@RequestMapping(value = "/checkCircuitBreaker", method = RequestMethod.GET)
	public String getCircuitBreakerfService() {
		
		
		//List<ServiceInstance> instances=discoveryClient.getInstances("EMPLOYEE-PRODUCER");  // this is for discovery client
		ServiceInstance serviceInstance=loadBalancer.choose("employee-producer");   // this is for loadbalancer client
		String baseUrl=serviceInstance.getUri().toString();
				baseUrl=baseUrl+"/staffservice";
		System.out.println(baseUrl);
		RestTemplate restTemplate = new RestTemplate();
		String response=null;
		
		
		response=restTemplate.getForObject(baseUrl,String.class);
		
		
		System.out.println("============"+response);
	
		
		return response;
		
	}


}
